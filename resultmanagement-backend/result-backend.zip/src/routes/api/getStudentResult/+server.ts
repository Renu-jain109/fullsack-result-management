import { connectDB } from "$lib/server/db";
import { Result } from "$lib/server/models/addNewResult";
import { json } from "@sveltejs/kit";

export async function POST(event:any) {
    let payLoad = await event.request.json();

    try{
        await connectDB();
        const user = await Result.findOne(payLoad);
        console.log(user);
        

        return json({data:user, result:true},  {
            headers: {
                'Access-Control-Allow-Origin': '*', // Allow all origins
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            }
        });
    }
    catch(error){
        return json({status:"error", data:"error"});
    }
       
}
export const OPTIONS = async () => {
    return new Response(null, {
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        }
    });
};
