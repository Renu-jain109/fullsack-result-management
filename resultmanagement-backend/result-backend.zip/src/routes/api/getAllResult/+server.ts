import { connectDB } from "$lib/server/db";
import { Result } from "$lib/server/models/addNewResult";
import { json } from "@sveltejs/kit";
import { checkAuthoraization } from "$lib/server/utils/common-utils";


export async function GET(event: any) {
    try {
let authoraized = checkAuthoraization(event);
        if(authoraized){
            await connectDB();
            const user = await Result.find();
            console.log(user);
            
            return json({ data: user }
            );
    
        }
    

        }
        catch (error) {
            console.log(error);
            return json({ status: "error", data: "error" });
    
        }


}
